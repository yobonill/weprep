<?php 
	$config = array(
		'__MYSQL_SERVER__' => 'localhost',
		'__MYSQL_USER__' => 'root',
		'__MYSQL_PASS__' => '',
		'__MYSQL_DATABASE__' => 'weprep',
		'__DOCUMENT_ROOT__' => '/opt/lampp/htdocs/weprep/core'
	)
?>